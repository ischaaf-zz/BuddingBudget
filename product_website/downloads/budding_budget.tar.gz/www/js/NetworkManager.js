// This is by far the most poorly defined of the classes, because
// I'm not 100% sure how it interfaces or what it needs to do.

var NetworkManager = function() {

	var credentials = {};

	this.login = function(user, pass) {

	};

	this.fetchInitialData = function(success, failure) {
		return {};
	};

	this.store = function(type, newData) {

	};

};